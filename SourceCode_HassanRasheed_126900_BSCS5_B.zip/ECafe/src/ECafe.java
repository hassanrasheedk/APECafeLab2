
import ecafe.Controller.CreateMenu;
import ecafe.View.OrderView;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author hassa
 */
public class ECafe {
     public static void main(String args[]){
         CreateMenu menuCreate=new CreateMenu();
         OrderView.displayMenu(menuCreate.getMenu());
         OrderView.takingOrder();
     }
}
