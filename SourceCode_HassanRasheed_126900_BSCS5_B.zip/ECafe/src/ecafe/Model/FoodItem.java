/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Model;

/**
 *
 * @author hassa
 */
public class FoodItem {
    String name;//name of food item
    String type;//type of food item i.e. appetizer, soup, main course dish, side dish
    String description;//description of food item
    double price;//price of the food item
    int time;//time it takes to prepare the food item in minutes
    double qty;
    
    public FoodItem(String name, String type, double price, String description){
        this.name=name;
        this.type=type;
        this.price=price;
        setTime(type);
        this.description=description;
    }
    
    public String getName(){
        return name;
    }
    public String getType(){
        return type;
    }
    public double getPrice(){
        return price;
    }
    public String getDesc(){
        return description;
    }
    public double getQty(){
        return qty;
    }
    
    public FoodItem(String name, String type, double price){
        this.name=name;
        this.type=type;
        this.price=price;
        setTime(type);
    }
    
    public FoodItem(String name, double price, double qty){
        this.name=name;
        this.price=price;
        this.qty=qty;
    }
    
    public void setTime(String type){        
        if(null != type) //sets time of the order depending on the type of food item
        switch (type) {
            case "appetizer":
                this.time=5;
                break;
            case "soup":
                this.time=10;
                break;
            case "maindish":
            case "Main Dish":
                this.time=15;
                break;
            case "sidedish":
            case "Side Dish":
                this.time=3;
                break;
            default:
                break;
        }
    }
    
}


