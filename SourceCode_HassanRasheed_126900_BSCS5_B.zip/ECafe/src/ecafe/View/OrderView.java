/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.View;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import ecafe.Controller.CreateMenu;
import ecafe.Controller.CreateOrder;
import ecafe.Model.Customer;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author hassa
 */
public class OrderView {
    static Customer customer;
    
    
    public static void customerDetails(String name, String contactnumber, String address){
        customer=new Customer(name,contactnumber,address);
    }
    
    public static void displayMenu(CafeMenu newmenu){
        CafeMenu menu=new CafeMenu();
        CreateMenu menuCreate=new CreateMenu();
        menu=menuCreate.CreatingMenu2();
        int i=0;
        for (FoodItem item : menu.MenuList) {
            i++;
            System.out.println(i+":\t"+item.getName()+"\t"+item.getType()+"\t"+item.getPrice()+"\t"+item.getDesc());
        }
    }
    
    public static void takingOrder(){
        Scanner input=new Scanner(System.in);
        CreateOrder co=new CreateOrder();
        int timefororder=0;
        while(true){
            System.out.println("Enter the serial number of the item you want to select.");
            int choice=input.nextInt();
            System.out.println("Enter quantity:");
            int qty=input.nextInt();
            switch (choice) {
                case 1:  
                    co.addToOrder("Zucchini Parmesan", 275, qty);
                    timefororder+=5;
                    break;
                case 2:  
                    co.addToOrder("Buffalo Chicken Tenders", 300, qty);
                    timefororder+=5;        
                    break;
                case 3:  
                    co.addToOrder("Hummus", 250, qty);
                    timefororder+=5;
                    break;
                case 4:  
                    co.addToOrder("Nachos", 250, qty);
                    timefororder+=5;
                    break;
                case 5:  
                    co.addToOrder("Chicken Vegetable Soup", 500, qty);
                    timefororder+=10;
                    break;
                case 6:  
                    co.addToOrder("Red Chilli Soup", 300, qty);
                    timefororder+=10;
                    break;
                case 7:  
                    co.addToOrder("Orange Chicken Skewers with Jalapeño-Mint Yogurt Dip", 800, qty);
                    timefororder+=15;
                    break;
                case 8:  
                    co.addToOrder("Ahi Tuna Poke Pizza", 1000, qty);
                    timefororder+=15;
                    break;
                case 9:  
                    co.addToOrder("Tandoori Lamb Pizza", 1000, qty);
                    timefororder+=15;
                    break;
                case 10: 
                    co.addToOrder("Lechon", 1800, qty);
                    timefororder+=15;
                    break;
                case 11: 
                    co.addToOrder("Master Turkey Meatloaf", 1200, qty);
                    timefororder+=15;
                    break;
                case 12: 
                    co.addToOrder("The Best Beefy Vegan Burger", 800, qty);
                    timefororder+=15;
                    break;
                case 13: 
                    co.addToOrder("Roasted Mushrooms with Herbs", 200, qty);
                    timefororder+=3;
                    break;
                case 14: 
                    co.addToOrder("Couscous & Goat Cheese Stuffed Tomatoes", 200, qty);
                    timefororder+=3;
                    break;
                case 15:
                    co.addToOrder("Roasted Cabbage with Bacon", 350, qty);
                    timefororder+=3;
                    break;
                default: 
                    System.out.println("Invalid order number");
                    break;
            }
            System.out.println("Do you want to add more items to your order? (Enter y/n)");
            Scanner inputa=new Scanner(System.in);
            String yesno=inputa.nextLine();
            if("Y".equals(yesno)||"y".equals(yesno))
                continue;
            break;
        }
        co.printOrder();
        System.out.println("Time required for order: "+timefororder+" minutes");
    }
    
}
