/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import java.util.Scanner;

/**
 *
 * @author hassa
 */
public class CreateMenu {
    CafeMenu myMenu=new CafeMenu();

    public CreateMenu(){}
    public void CreatingMenu1(){
        String name, type, description; 
        double price, minutesTomake;
        for(int i=0;i<15;i++){
            Scanner inputString=new Scanner(System.in);
            Scanner inputDouble=new Scanner(System.in);
            System.out.println("Enter name of the Food Item "+(i+1)+":");
            name=inputString.nextLine();
            System.out.println("Enter type of the Food Item "+(i+1)+":");
            type=inputString.nextLine();
            System.out.println("Enter price of the Food Item "+(i+1)+":");
            price=inputDouble.nextDouble();
           
            System.out.println("Enter description of the Food Item "+(i+1)+":");
            description=inputString.nextLine();
            FoodItem item=new FoodItem(name,type,price,description);
            myMenu.addItem(item);
            System.out.println("Mekoenu Item Added!");
        }
    }
    
    public CafeMenu CreatingMenu2(){
            FoodItem item=new FoodItem("Zucchini Parmesan","Appetizer",275,"served with ranch dressing");
            myMenu.addItem(item);
            FoodItem item2=new FoodItem("Buffalo Chicken Tenders","Appetizer",300,"all white chicken in a light gluten free breading with just the right amount of hot!");
            myMenu.addItem(item2);
            FoodItem item3=new FoodItem("Hummus","Appetizer",250,"not available at Hermosa Beach");
            myMenu.addItem(item3);
            FoodItem item4=new FoodItem("Nachos","Appetizer",250,"multi-colored chips topped with black beans, cheese, green onions, guacamole & sour cream");
            myMenu.addItem(item4);
            FoodItem item5=new FoodItem("Chicken Vegetable Soup","Soup",500,"");
            myMenu.addItem(item5);
            FoodItem item6=new FoodItem("Red Chilli Soup","Soup",300,"");
            myMenu.addItem(item6);
            FoodItem item7=new FoodItem("Orange Chicken Skewers with Jalapeño-Mint Yogurt Dip ","Main Dish",800,"");
            myMenu.addItem(item7);
            FoodItem item8=new FoodItem("Ahi Tuna Poke Pizza","Main Dish",1000,"This fresh, spring-inspired vehicle for poke proves that pizza doesn’t have to be unhealthy! You'll want to use the freshest ahi tuna you can get your hands on for this vibrant, company-worthy entree.");
            myMenu.addItem(item8);
            FoodItem item9=new FoodItem("Tandoori Lamb Pizza","Main Dish",1000,"This pizza is loaded with fantastic tandoori flavor and ground lamb, giving it an authentic edge and creating one big burst of flavors all on one pizza.");
            myMenu.addItem(item9);
            FoodItem item10=new FoodItem("Lechon","Main Dish",1800,"A traditional pork dish from Spain, lechón is a suckling pig that's roasted.");
            myMenu.addItem(item10);
            FoodItem item11=new FoodItem("Master Turkey Meatloaf","Main Dish",1200,"This is the ultimate, foolproof, turkey meatloaf that is every kind of comforting that you would want a meatloaf to be.");
            myMenu.addItem(item11);
            FoodItem item12=new FoodItem("The Best Beefy Vegan Burger","Main Dish",800,"This umami-rich burger unabashedly attempts to imitate a beef burger in flavor, texture, and appearance");
            myMenu.addItem(item12);
            FoodItem item13=new FoodItem("Roasted Mushrooms with Herbs","Side Dish",200,"Roasted Mushrooms with Herbs");
            myMenu.addItem(item13);
            FoodItem item14=new FoodItem("Couscous & Goat Cheese Stuffed Tomatoes","Side Dish",200,"Couscous & Goat Cheese Stuffed Tomatoes");
            myMenu.addItem(item14);
            FoodItem item15=new FoodItem("Roasted Cabbage with Bacon","Side Dish",350,"Roasted Cabbage with Bacon");
            myMenu.addItem(item15);
            return myMenu;
    }
    
    public CafeMenu getMenu(){
        return myMenu;
    }
}

