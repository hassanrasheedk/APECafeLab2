/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecafe.Controller;

import ecafe.Model.CafeMenu;
import ecafe.Model.FoodItem;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author hassa
 */
public class CreateOrder {
    String customerName;
    String contactNumber;
    String address;
    double bill;
    List<FoodItem> items=new ArrayList();
    
    public CreateOrder(){}
    
    public void addToOrder(String itemName,double price, double qty){
        FoodItem item=new FoodItem(itemName,price,qty);
        items.add(item);
        this.bill=this.bill+(price*qty);
    }

    public double getBill(){
        return bill;
    }
    
    public void printOrder(){
    System.out.println(customerName+"\t"+contactNumber+"\t"+address);
    System.out.println("Item\tQuantity\tUnit Price\tTotal Price");
    Iterator itr=items.iterator();
    while(itr.hasNext()){
        FoodItem item=(FoodItem) itr.next();
        System.out.println(item.getName()+"\t"+item.getQty()+"\t"+item.getPrice()+"\t"+(item.getQty()*item.getPrice()));
    }
    System.out.println("Total Bill:"+bill);
    
    }
    
}
